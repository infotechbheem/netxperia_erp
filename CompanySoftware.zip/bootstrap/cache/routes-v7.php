<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EZzx7ToeI1eu7L9a',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'auth.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/project-category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.project.project-category',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/project-category-create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.project-category.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/project-assigned' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/create-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.project.create-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/store-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.project.store-project',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/assign-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.project.assign-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/store-assign-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.assign-project',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/project/department/get-employee' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mu4cWTwHeOOIxRGU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/notice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/notices/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notice.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/department-designation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.department-designation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/store-department' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.store-department',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/store-designation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.store-designation',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/registration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.registration',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/emp-ragistration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.registration.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/performances' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.performance',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.view',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/schedule' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.schedule',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/schedule-store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.store-schedule',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/log' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.log',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/view-filter-attendance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.filteredAttendance',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/leave/leave-request' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.leave-request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/employee/attendance/leave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.leave',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/registration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.registration',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/registration-store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/support-ticket' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.support-ticket',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/project/requested-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.project.requested-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/project/current-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.project.current-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/project/store-assign-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.assign-project',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/project/completed-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.project.completed-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/invoices/generate-invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.invoices.generate-invoice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/invoices/project-invoice-store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.invoice.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/invoices/view-project-invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.invoices.view-invoice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/communication/support-tickets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.communication.support-tickets',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/communication/support-ticket-response' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.communication.support-ticket-response-store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/communication/change-ticket-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.communication.change-status',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/hosting/hosting-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.hosting',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/hosting/add-hosting-detials' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.hosting.add-hosting-details',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/hosting/save-hostng-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.hosting.save-hosting-details',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/client/hosting/renewal-hosting-plan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.hosting.renew-plans',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor-profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/vendor-registration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.registration',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/current-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.project.current-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/store-assign-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.project.store-assign-project',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/assigned-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.project.assigned-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/project/completed-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.project.completed-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/payments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.payments',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/admin/vendor/payments/make-payments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.payments.store-payments-details',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-barcode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9vNm1trspgxYDo7n',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project/current-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.current-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project/update-project-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.update-project-details',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project/completed-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.completed-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project/send-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.send-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project/store-send-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.store-send-project',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project/completed-sended-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.completed-sended-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/resource' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.resources',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/collaboration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.collaborations',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.support',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/project-analytics-and-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.analytics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/payment-tracking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.payments',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/vendor/payment-tracking/record-activity' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.payments.record-activity',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/project/current-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.project.current-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/project/create-new-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.project.create-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/project/store-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.project.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/project/completed-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.project.completed-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/invoice/view-invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.invoice.view-invoice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/invoice/payment-history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.invoice.payment-history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/invoice/generate-invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.invoice.generate-invoice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/communication/support-tickets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.communication.support-tickets',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/communication/contact-support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.communication.contact-support',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/communication/support-ticket-store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.communication.support-ticket-store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/client/communication/store-support-ticket' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.communication.chat-support-ticket-store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/view-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/project/currenct-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.project.current-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/project/update-current-project-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.project.update-project-details',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/project/completed-project' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.project.completed-project',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/mark-attendance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.mark-attendance',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/attendance-store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/leave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.leave',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/leave/apply-leave-form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.apply-leave',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/leave/stored-applied-form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.create-leave-application',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/employee/attendance/leave/track-application' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'employee.attendance.track-application',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/auth/(?|admin/(?|project/(?|project\\-(?|category\\-delete/([^/]++)(*:73)|view/([^/]++)(*:93))|get\\-project\\-details/([^/]++)(*:131))|employee/(?|emp\\-profile/([^/]++)(*:173)|attendance/(?|schedule\\-edit/([^/]++)(*:218)|leave/leave\\-(?|details/([^/]++)(*:258)|update\\-status/([^/]++)(*:289))))|client/(?|pro(?|file/([^/]++)(*:329)|ject/view\\-requested\\-project/([^/]++)(*:375))|invoices/project\\-(?|invoice\\-generate/([^/]++)/([^/]++)(*:440)|view\\-invoice/([^/]++)(*:470))|communication/view\\-support\\-ticket/([^/]++)(*:523)|hosting/hosting\\-details\\-view/([^/]++)(*:570))|vendor/(?|vendor\\-profile/([^/]++)(*:613)|p(?|roject/view\\-(?|assigned\\-project/([^/]++)(*:667)|completed\\-project/([^/]++)(*:702))|ayments/(?|view\\-payment\\-details/([^/]++)(*:753)|get\\-project\\-details/([^/]++)(*:791)))))|vendor/p(?|roject/view\\-completed\\-sended\\-project/([^/]++)(*:862)|ayment\\-tracking/view\\-payment\\-details/([^/]++)(*:918))|client/(?|invoice/(?|view\\-project\\-invoice/([^/]++)(*:979)|download\\-invoice/([^/]++)(*:1013))|communication/view\\-support\\-ticket/([^/]++)(*:1067)))|/storage/(.*)(*:1091))/?$}sDu',
    ),
    3 => 
    array (
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.project-category.delete',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      93 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.project.view-project',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      131 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XOPtP5kPWdVkFjbX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.profile',
          ),
          1 => 
          array (
            0 => 'encryptedId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.attendance.edit-schedule',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.leave-details',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.employee.update-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      329 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.profile',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      375 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.project.view-requested-project',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      440 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.invoices.project-invoice-generate',
          ),
          1 => 
          array (
            0 => 'project_id',
            1 => 'client_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      470 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.invoices.view.project-view-invoice',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.communication.view-support-ticket',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      570 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.client.hosting.hosting-details-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor-profile.profile',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      667 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.project.view-assigned-project',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      702 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.project.view-vendor-completed-project',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      753 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.vendor.payments.view-payment-details',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      791 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AeN5ro6h2aaLnVhh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      862 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.project.view-sended-project',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      918 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'vendor.payments.view-payment-details',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      979 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.invoice.view-project-invoice',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1013 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.invoice.download-invoice',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1067 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'client.communication.view-support-ticket',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1091 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::EZzx7ToeI1eu7L9a' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:372:"function () {
                    \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);

                    return \\Illuminate\\Support\\Facades\\View::file(\'C:\\\\xampp\\\\htdocs\\\\software\\\\CompanySoftware\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\');
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000005220000000000000000";}}',
        'as' => 'generated::EZzx7ToeI1eu7L9a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:50:"function () {
        return \\view(\'login\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000052a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'auth.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'auth.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\DashboardController@dashboard',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\DashboardController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\DashboardController@logout',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.project.project-category' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/project-category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProjectCategory',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProjectCategory',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.project.project-category',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.project-category.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/project/project-category-create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProjectCategoryCreate',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProjectCategoryCreate',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.project-category.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.project-category.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/project-category-delete/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProjectCategoryDelete',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProjectCategoryDelete',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.project-category.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/project-assigned',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empProject',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XOPtP5kPWdVkFjbX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/get-project-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@getProjectDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@getProjectDetails',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::XOPtP5kPWdVkFjbX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.project.create-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/create-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empCreateItProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@empCreateItProject',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.project.create-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.project.store-project' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/project/store-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@storeProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@storeProject',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.project.store-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.project.assign-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/assign-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@allRequestedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@allRequestedProject',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.project.assign-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.assign-project' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/project/store-assign-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@storeAssignProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@storeAssignProject',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.assign-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.project.view-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/project-view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@projectView',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@projectView',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.project.view-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mu4cWTwHeOOIxRGU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/project/department/get-employee',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@getEmployee',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\ProjectController@getEmployee',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::mu4cWTwHeOOIxRGU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/notice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\NoticeController@noticeBoard',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\NoticeController@noticeBoard',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.notice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notice.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/notices/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\NoticeController@storeNotice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\NoticeController@storeNotice',
        'namespace' => NULL,
        'prefix' => '/auth/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.notice.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.department-designation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/department-designation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@departmentAndDesignation',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@departmentAndDesignation',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.department-designation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.store-department' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/employee/store-department',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@storeDepartment',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@storeDepartment',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.store-department',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.store-designation' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/employee/store-designation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@storeDesignation',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@storeDesignation',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.store-designation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@index',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.registration' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/registration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@empRegistration',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@empRegistration',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.registration',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.registration.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/employee/emp-ragistration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@storeEmpRegistration',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@storeEmpRegistration',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.registration.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/emp-profile/{encryptedId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@empProfile',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@empProfile',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.performance' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/performances',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@empPerformance',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\EmployeeController@empPerformance',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.performance',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@addAttendance',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@addAttendance',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/employee/attendance/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@storeAttendance',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@storeAttendance',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@viewAttendance',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@viewAttendance',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.schedule' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/schedule',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@EmpAttendanceSchedule',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@EmpAttendanceSchedule',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.schedule',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.store-schedule' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/employee/attendance/schedule-store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@scheduleStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@scheduleStore',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.store-schedule',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.edit-schedule' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'auth/admin/employee/attendance/schedule-edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@scheduleEdit',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@scheduleEdit',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.edit-schedule',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.log' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/log',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@attendanceLog',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@attendanceLog',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.log',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.attendance.filteredAttendance' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/view-filter-attendance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@filteredAttendance',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\EmpAttendanceController@filteredAttendance',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.attendance.filteredAttendance',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.leave-request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/leave/leave-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@leaveRequest',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@leaveRequest',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance/leave',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.leave-request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.leave-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/leave/leave-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@leaveDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@leaveDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance/leave',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.leave-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.update-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/employee/attendance/leave/leave-update-status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@updateStatus',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance/leave',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.update-status',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.employee.leave' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/employee/attendance/leave',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@empLeave',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Employee\\LeaveController@empLeave',
        'namespace' => NULL,
        'prefix' => 'auth/admin/employee/attendance/leave',
        'where' => 
        array (
        ),
        'as' => 'admin.employee.leave',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@index',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client',
        'where' => 
        array (
        ),
        'as' => 'admin.client',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.registration' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/registration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@registration',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@registration',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client',
        'where' => 
        array (
        ),
        'as' => 'admin.client.registration',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/registration-store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@store',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client',
        'where' => 
        array (
        ),
        'as' => 'admin.client.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/profile/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@profile',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@profile',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client',
        'where' => 
        array (
        ),
        'as' => 'admin.client.profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.support-ticket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/support-ticket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@supportTicket',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ClientController@supportTicket',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client',
        'where' => 
        array (
        ),
        'as' => 'admin.client.support-ticket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.project.requested-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/project/requested-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@requestedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@requestedProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/project',
        'where' => 
        array (
        ),
        'as' => 'admin.client.project.requested-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.project.current-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/project/current-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@currentProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@currentProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/project',
        'where' => 
        array (
        ),
        'as' => 'admin.client.project.current-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.project.view-requested-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/project/view-requested-project/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@viewRequestedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@viewRequestedProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/project',
        'where' => 
        array (
        ),
        'as' => 'admin.client.project.view-requested-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.assign-project' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/project/store-assign-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@clientStoreAssignProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@clientStoreAssignProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/project',
        'where' => 
        array (
        ),
        'as' => 'admin.client.assign-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.project.completed-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/project/completed-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@completedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\ProjectController@completedProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/project',
        'where' => 
        array (
        ),
        'as' => 'admin.client.project.completed-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.invoices.generate-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/invoices/generate-invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@generateInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@generateInvoice',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/invoices',
        'where' => 
        array (
        ),
        'as' => 'admin.client.invoices.generate-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.invoices.project-invoice-generate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/invoices/project-invoice-generate/{project_id}/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@projectInvoiceGenerate',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@projectInvoiceGenerate',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/invoices',
        'where' => 
        array (
        ),
        'as' => 'admin.client.invoices.project-invoice-generate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.invoice.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/invoices/project-invoice-store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@invoiceStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@invoiceStore',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/invoices',
        'where' => 
        array (
        ),
        'as' => 'admin.client.invoice.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.invoices.view-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/invoices/view-project-invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@viewInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@viewInvoice',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/invoices',
        'where' => 
        array (
        ),
        'as' => 'admin.client.invoices.view-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.invoices.view.project-view-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/invoices/project-view-invoice/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@projectViewInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\InvoiceController@projectViewInvoice',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/invoices',
        'where' => 
        array (
        ),
        'as' => 'admin.client.invoices.view.project-view-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.communication.support-tickets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/communication/support-tickets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@supportTickets',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@supportTickets',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/communication',
        'where' => 
        array (
        ),
        'as' => 'admin.client.communication.support-tickets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.communication.view-support-ticket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/communication/view-support-ticket/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@viewSupportTicket',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@viewSupportTicket',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/communication',
        'where' => 
        array (
        ),
        'as' => 'admin.client.communication.view-support-ticket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.communication.support-ticket-response-store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/communication/support-ticket-response',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@supportTicketResponseStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@supportTicketResponseStore',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/communication',
        'where' => 
        array (
        ),
        'as' => 'admin.client.communication.support-ticket-response-store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.communication.change-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/communication/change-ticket-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@changeTicketStatus',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\CommunicationController@changeTicketStatus',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/communication',
        'where' => 
        array (
        ),
        'as' => 'admin.client.communication.change-status',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.hosting' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/hosting/hosting-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@hostingDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@hostingDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/hosting',
        'where' => 
        array (
        ),
        'as' => 'admin.client.hosting',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.hosting.add-hosting-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/hosting/add-hosting-detials',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@addHostingDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@addHostingDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/hosting',
        'where' => 
        array (
        ),
        'as' => 'admin.client.hosting.add-hosting-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.hosting.save-hosting-details' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/hosting/save-hostng-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@saveHostingDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@saveHostingDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/hosting',
        'where' => 
        array (
        ),
        'as' => 'admin.client.hosting.save-hosting-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.hosting.renew-plans' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/client/hosting/renewal-hosting-plan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@renewalHostingPlan',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@renewalHostingPlan',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/hosting',
        'where' => 
        array (
        ),
        'as' => 'admin.client.hosting.renew-plans',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.client.hosting.hosting-details-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/client/hosting/hosting-details-view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@viewHostingDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Client\\HostingController@viewHostingDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/client/hosting',
        'where' => 
        array (
        ),
        'as' => 'admin.client.hosting.hosting-details-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor-profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@index',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor-profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor-profile.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/vendor-profile/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@vendorProfile',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@vendorProfile',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor-profile.profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.registration' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/vendor-registration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@vendorRegistration',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@vendorRegistration',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.registration',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/vendor/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorRegistration@store',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.project.current-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/current-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@currentProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@currentProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.project.current-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.project.store-assign-project' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/vendor/store-assign-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@storeAssignProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@storeAssignProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.project.store-assign-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.project.assigned-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/assigned-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@AssignedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@AssignedProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.project.assigned-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.project.view-assigned-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/project/view-assigned-project/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@getProjectDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@getProjectDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.project.view-assigned-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.project.completed-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/project/completed-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@completedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@completedProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.project.completed-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.project.view-vendor-completed-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/project/view-completed-project/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@viewVendorcompletedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorProjectController@viewVendorcompletedProject',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.project.view-vendor-completed-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.payments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/payments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@index',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.payments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.payments.view-payment-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/payments/view-payment-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@viewPaymentDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@viewPaymentDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.payments.view-payment-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AeN5ro6h2aaLnVhh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/admin/vendor/payments/get-project-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@projectDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@projectDetails',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::AeN5ro6h2aaLnVhh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.vendor.payments.store-payments-details' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/admin/vendor/payments/make-payments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@makePayment',
        'controller' => 'App\\Http\\Controllers\\Auth\\Admin\\Vendor\\VendorPaymentController@makePayment',
        'namespace' => NULL,
        'prefix' => 'auth/admin/vendor',
        'where' => 
        array (
        ),
        'as' => 'admin.vendor.payments.store-payments-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9vNm1trspgxYDo7n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get-barcode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:220:"function () {
    $generator = new \\Picqer\\Barcode\\BarcodeGeneratorHTML();
    $barcode = $generator->getBarcode(\'Bheem Kumar Sharma\', $generator::TYPE_CODE_128);

    return \\view(\'barcode\', \\compact(\'barcode\'));
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005280000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9vNm1trspgxYDo7n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\DashboardController@dashboard',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\DashboardController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\DashboardController@logout',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.current-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/project/current-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@currentProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@currentProject',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.current-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.update-project-details' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/vendor/project/update-project-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@updateProjectDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@updateProjectDetails',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.update-project-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.completed-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/project/completed-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@completedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@completedProject',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.completed-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.send-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/project/send-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@sendProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@sendProject',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.send-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.store-send-project' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/vendor/project/store-send-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@stoerSendProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@stoerSendProject',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.store-send-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.completed-sended-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/project/completed-sended-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@completedSendedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@completedSendedProject',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.completed-sended-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.project.view-sended-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/project/view-completed-sended-project/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@viewSendedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectController@viewSendedProject',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.project.view-sended-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.resources' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/resource',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ResourceController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ResourceController@index',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.resources',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.collaborations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/collaboration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\CollaborationController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\CollaborationController@index',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.collaborations',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.support' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\SupportController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\SupportController@index',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.support',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.analytics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/project-analytics-and-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectAnalyticsReportController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\ProjectAnalyticsReportController@index',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.analytics',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.payments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/payment-tracking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\PaymentTrackingController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\PaymentTrackingController@index',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.payments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.payments.record-activity' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/payment-tracking/record-activity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\PaymentTrackingController@recordActivity',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\PaymentTrackingController@recordActivity',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.payments.record-activity',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'vendor.payments.view-payment-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/vendor/payment-tracking/view-payment-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_vendor',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Vendor\\PaymentTrackingController@viewPaymentDetails',
        'controller' => 'App\\Http\\Controllers\\Auth\\Vendor\\PaymentTrackingController@viewPaymentDetails',
        'namespace' => NULL,
        'prefix' => '/auth/vendor',
        'where' => 
        array (
        ),
        'as' => 'vendor.payments.view-payment-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\DashboardController@dashboard',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\DashboardController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\DashboardController@logout',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.project.current-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/project/current-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@currentProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@currentProject',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.project.current-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.project.create-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/project/create-new-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@createNewProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@createNewProject',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.project.create-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.project.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/client/project/store-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@projectStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@projectStore',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.project.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.project.completed-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/project/completed-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@completedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\ProjectController@completedProject',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.project.completed-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.invoice.view-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/invoice/view-invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@viewInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@viewInvoice',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.invoice.view-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.invoice.payment-history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/invoice/payment-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@paymentHistory',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@paymentHistory',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.invoice.payment-history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.invoice.generate-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/invoice/generate-invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@generateInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@generateInvoice',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.invoice.generate-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.invoice.view-project-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/invoice/view-project-invoice/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@viewProjectInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@viewProjectInvoice',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.invoice.view-project-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.invoice.download-invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/invoice/download-invoice/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@downloadInvoice',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\InvoiceController@downloadInvoice',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.invoice.download-invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.communication.support-tickets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/communication/support-tickets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@supportTickets',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@supportTickets',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.communication.support-tickets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.communication.contact-support' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/communication/contact-support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@contactSupport',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@contactSupport',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.communication.contact-support',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.communication.support-ticket-store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/client/communication/support-ticket-store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@supportTicketStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@supportTicketStore',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.communication.support-ticket-store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.communication.view-support-ticket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/client/communication/view-support-ticket/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@viewSupportTicket',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@viewSupportTicket',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.communication.view-support-ticket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'client.communication.chat-support-ticket-store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/client/communication/store-support-ticket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_client',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@chatSupportTicketStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Client\\CommunicationController@chatSupportTicketStore',
        'namespace' => NULL,
        'prefix' => '/auth/client',
        'where' => 
        array (
        ),
        'as' => 'client.communication.chat-support-ticket-store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\DashboardController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\DashboardController@dashboard',
        'namespace' => NULL,
        'prefix' => '/auth/employee',
        'where' => 
        array (
        ),
        'as' => 'employee.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\DashboardController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\DashboardController@logout',
        'namespace' => NULL,
        'prefix' => '/auth/employee',
        'where' => 
        array (
        ),
        'as' => 'employee.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/view-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\DashboardController@empProfile',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\DashboardController@empProfile',
        'namespace' => NULL,
        'prefix' => '/auth/employee',
        'where' => 
        array (
        ),
        'as' => 'employee.profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.project.current-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/project/currenct-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\ProjectController@currentProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\ProjectController@currentProject',
        'namespace' => NULL,
        'prefix' => '/auth/employee',
        'where' => 
        array (
        ),
        'as' => 'employee.project.current-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.project.update-project-details' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/employee/project/update-current-project-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\ProjectController@updateCurrentProjectStatus',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\ProjectController@updateCurrentProjectStatus',
        'namespace' => NULL,
        'prefix' => '/auth/employee',
        'where' => 
        array (
        ),
        'as' => 'employee.project.update-project-details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.project.completed-project' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/project/completed-project',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\ProjectController@completedProject',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\ProjectController@completedProject',
        'namespace' => NULL,
        'prefix' => '/auth/employee',
        'where' => 
        array (
        ),
        'as' => 'employee.project.completed-project',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.mark-attendance' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/attendance/mark-attendance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@markAttendance',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@markAttendance',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.mark-attendance',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/employee/attendance/attendance-store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@attendanceStore',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@attendanceStore',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/attendance/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@attendanceHistory',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@attendanceHistory',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.leave' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/attendance/leave',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@empLeave',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@empLeave',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.leave',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.apply-leave' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/attendance/leave/apply-leave-form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@applyLeaveForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@applyLeaveForm',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.apply-leave',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.create-leave-application' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/employee/attendance/leave/stored-applied-form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@storedLeaveApplicationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@storedLeaveApplicationForm',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.create-leave-application',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'employee.attendance.track-application' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/employee/attendance/leave/track-application',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'clear_cache',
          2 => 'auth_employee',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@trackApplication',
        'controller' => 'App\\Http\\Controllers\\Auth\\Employee\\AttendanceController@trackApplication',
        'namespace' => NULL,
        'prefix' => 'auth/employee/attendance',
        'where' => 
        array (
        ),
        'as' => 'employee.attendance.track-application',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:4:{s:6:"driver";s:5:"local";s:4:"root";s:60:"C:\\xampp\\htdocs\\software\\CompanySoftware\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000052d0000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
